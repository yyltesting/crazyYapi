!function(){"use strict";function e(e){const t=atob(e.base64);let r=t.length;const n=new Uint8Array(r);for(;r--;)n[r]=t.charCodeAt(r);return new File([n],e.name,{type:e.type})}var t,r,n,o,a,s=Object.create(null);function c(e){return void 0===s.inNode&&(s.inNode="undefined"!=typeof process&&null!=process.versions&&null!=process.versions.node),s.inNode&&"function"==typeof e&&e(),s.inNode}function u(){var e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",n=e.split("").reduce((function(e,t,r){return e[t]=r,e}),{}),o=String.fromCharCode,a=function(e){if(e.length<2){var t=e.charCodeAt(0);return t<128?e:t<2048?o(192|t>>>6)+o(128|63&t):o(224|t>>>12&15)+o(128|t>>>6&63)+o(128|63&t)}var r=65536+1024*(e.charCodeAt(0)-55296)+(e.charCodeAt(1)-56320);return o(240|r>>>18&7)+o(128|r>>>12&63)+o(128|r>>>6&63)+o(128|63&r)},s=/[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g,c=[0,2,1],u=function(t){var r=c[t.length%3],n=t.charCodeAt(0)<<16|(t.length>1?t.charCodeAt(1):0)<<8|(t.length>2?t.charCodeAt(2):0);return[e.charAt(n>>>18),e.charAt(n>>>12&63),r>=2?"=":e.charAt(n>>>6&63),r>=1?"=":e.charAt(63&n)].join("")};t=function(e){return function(e){return e.replace(s,a)}(e).replace(/[\s\S]{1,3}/g,u)};var i=new RegExp(["[À-ß][-¿]","[à-ï][-¿]{2}","[ð-÷][-¿]{3}"].join("|"),"g"),d=function(e){switch(e.length){case 4:var t=((7&e.charCodeAt(0))<<18|(63&e.charCodeAt(1))<<12|(63&e.charCodeAt(2))<<6|63&e.charCodeAt(3))-65536;return o(55296+(t>>>10))+o(56320+(1023&t));case 3:return o((15&e.charCodeAt(0))<<12|(63&e.charCodeAt(1))<<6|63&e.charCodeAt(2));default:return o((31&e.charCodeAt(0))<<6|63&e.charCodeAt(1))}},f=[0,0,2,1],l=function(e){var t=e.length,r=t%4,a=(t>0?n[e.charAt(0)]<<18:0)|(t>1?n[e.charAt(1)]<<12:0)|(t>2?n[e.charAt(2)]<<6:0)|(t>3?n[e.charAt(3)]:0),s=[o(a>>>16),o(a>>>8&255),o(255&a)];return s.length-=f[r],s.join("")};r=function(e){return t=e.replace(/=+$/,""),t.replace(/[\s\S]{1,4}/g,l).replace(i,d);var t}}function i(e){return function(e){return c()?Buffer.from(e).toString("base64"):(t||u(),t(e))}(e).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"")}function d(e){return function(e){return c()?Buffer.from(e,"base64").toString():(r||u(),r(e))}(e.replace(/-/g,"+").replace(/_/g,"/"))}function f(e){if(!e||"object"!=typeof e)return!1;var t=Object.getPrototypeOf(e);if(null===t)return!0;var r=t.constructor;return"function"==typeof r&&r instanceof r}function l(e,t){var r={};
/*!
   * vtils v2.57.0
   * (c) Jay Fong <fjc0kb@gmail.com> (https://github.com/fjc0k)
   * Released under the MIT License.
   */
return function(e,t){for(var r in e)if(Object.prototype.hasOwnProperty.call(e,r)&&!1===t(e[r],r,e))break}(e,(function(e,n,o){r[n]=t(e,n,o)})),r}c.clearCache=function(){delete s.inNode},function(e){e.open="open",e.closed="closed",e.leftOpenRightClosed="leftOpenRightClosed",e.leftClosedRightOpen="leftClosedRightOpen"}(n||(n={})),function(e){e.css="css",e.js="js",e.img="img"}(o||(o={})),function(e){e.desc="desc",e.asc="asc"}(a||(a={}));var p=function(e){this.list=e};p.transformIfNeeded=function(e,t){if(void 0===t&&(t=2),f(e)){if(!0===e.__IS_PACKED_STRUCTURED_LIST__)return new p(e).unpack();if(t>0)return l(e,(function(e){return p.transformIfNeeded(e,t-1)}))}return e},p.rot13=function(e){return e.replace(/[a-z]/gi,(function(e){return String.fromCharCode(e.charCodeAt(0)+(e.toLowerCase()<"n"?13:-13))}))},p.encodeValueIndexes=function(e){return p.rot13(i((new Date).getTime()+"."+e.join(".")))},p.decodeValueIndexes=function(e){return d(p.rot13(e)).split(".").slice(1).map(Number)},p.prototype.pack=function(){for(var e=this.list,t=e.length?Object.keys(e[0]):[],r=function(e){for(var t=e.slice(),r=t.length-1;r>=0;r--){var n=Math.floor(Math.random()*(r+1)),o=t[n];t[n]=t[r],t[r]=o}return t}(function(e,t,r){void 0===r&&(r=1);for(var n=[],o=e<t;o?e<t:e>t;)n.push(e),e+=r;return n}(0,t.length)),n=[],o=0,a=e;o<a.length;o+=1){for(var s=a[o],c=[],u=0,i=r.length;u<i;u++)c[r[u]]=s[t[u]];n.push(c)}return{__IS_PACKED_STRUCTURED_LIST__:!0,keys:t,values:n,signature:p.encodeValueIndexes(r)}},p.prototype.packAsHttpResponse=function(){return this.pack()},p.prototype.unpack=function(){for(var e=this.list,t=[],r=p.decodeValueIndexes(e.signature),n=0,o=e.values;n<o.length;n+=1){for(var a=o[n],s={},c=0,u=r.length;c<u;c++)s[e.keys[c]]=a[r[c]];t.push(s)}return t},chrome.runtime.onMessage.addListener((t,r,n)=>{
  var o;
  return(o=async()=>{
    switch(t.type){
      case"__YAPIX_BACKGROUND_HTTP_REQUEST__":
        if(t.options.headers){
          t.options.headers["x-yapix-http-headers"]=JSON.stringify(t.options.headers);
        }
        if(f(t.options.body)&&!0===t.options.body.__YAPIX_FILE_BODY__){
          const r={...t.options.body};
          delete r.__YAPIX_FILE_BODY__;
          const n=new FormData;
          for(const[t,o]of Object.entries(r))
            f(o)&&!0===o.__YAPIX_BASE64_FILE__?n.append(t,e(o)):n.append(t,o);
          t.options.body=n;
        }
        
        try {
          const r=await fetch(t.options.url,t.options);
          const o=new Headers(r.headers);
          const a=o.get("x-yapix-http-headers");
          const headers = {};
          
          for (const [name, value] of o.entries()) {
            headers[name] = value;
          }

          const c=function(e,t,r){
            let n="";
            const o=new Uint8Array(e);
            const a=o.byteLength;
            for(let e=0;e<a;e++)
              n+=String.fromCharCode(o[e]);
            return{
              __YAPIX_BASE64_FILE__:!0,
              base64:btoa(n),
              name:t,
              type:r
            }
          }(await r.arrayBuffer(),"file",headers["content-type"]||"application/octet-stream");

          const{ok:u,status:i,statusText:d}=r;
          n({
            error:null,
            data:{
              ok:u,
              status:i,
              statusText:d,
              headers:headers,
              base64File:c
            }
          });
        } catch(e) {
          n({error:String(e)});
        }
        break;
    }
  },o()).catch(e=>{
    n({error:String(e)})
  }),!0
});}();
